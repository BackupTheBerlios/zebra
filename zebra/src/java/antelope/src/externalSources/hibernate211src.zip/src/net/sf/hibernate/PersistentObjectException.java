//$Id: PersistentObjectException.java,v 1.4.2.1 2003/11/27 09:30:48 oneovthafew Exp $
package net.sf.hibernate;

/**
 * Throw when the user passes a persistent instance to a <tt>Session</tt>
 * method that expects a transient instance.
 * 
 * @author Gavin King
 */
public class PersistentObjectException extends HibernateException {
	
	public PersistentObjectException(String s) {
		super(s);
	}
	
}






