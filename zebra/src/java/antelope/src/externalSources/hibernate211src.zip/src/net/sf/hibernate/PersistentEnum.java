//$Id: PersistentEnum.java,v 1.5 2003/06/19 05:07:03 oneovthafew Exp $
package net.sf.hibernate;

/**
 * Implementors of <tt>PersistentEnum</tt> are enumerated types persisted to
 * the database as <tt>SMALLINT</tt>s. As well as implementing <tt>toInt()</tt>,
 * a <tt>PersistentEnum</tt> must also provide a static method with the
 * signature:<br>
 * <br>
 * 		<tt>public static PersistentEnum fromInt(int i)</tt>
 *
 * @author Gavin King
 */
public interface PersistentEnum {
	public int toInt();
}






