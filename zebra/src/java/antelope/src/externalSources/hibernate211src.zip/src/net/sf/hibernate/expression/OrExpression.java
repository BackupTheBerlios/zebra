//$Id: OrExpression.java,v 1.3.2.1 2003/08/12 12:51:00 oneovthafew Exp $
package net.sf.hibernate.expression;


/**
 * A logical "or"
 * @author Gavin King
 */
public class OrExpression extends LogicalExpression {
	
	String getOp() {
		return "or";
	}
		
	OrExpression(Criterion lhs, Criterion rhs) {
		super(lhs, rhs);
	}

}
