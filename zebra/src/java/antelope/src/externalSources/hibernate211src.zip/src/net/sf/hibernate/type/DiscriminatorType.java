//$Id: DiscriminatorType.java,v 1.4.2.1 2003/11/21 16:06:40 oneovthafew Exp $
package net.sf.hibernate.type;

/**
 * A <tt>Type</tt> that may be used for a discriminator column.
 * @author Gavin King
 */
public interface DiscriminatorType extends IdentifierType, LiteralType {
}






