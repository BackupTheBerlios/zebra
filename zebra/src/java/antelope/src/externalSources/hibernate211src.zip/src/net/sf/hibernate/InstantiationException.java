//$Id: InstantiationException.java,v 1.4 2003/04/25 03:40:29 oneovthafew Exp $
package net.sf.hibernate;

/**
 * Thrown if Hibernate can't instantiate an entity or component
 * class at runtime.
 * 
 * @author Gavin King
 */

public class InstantiationException extends HibernateException {
	
	private final Class clazz;
	
	public InstantiationException(String s, Class clazz, Throwable root) {
		super(s, root);
		this.clazz = clazz;
	}
	
	public Class getPersistentClass() {
		return clazz;
	}
	
	public String getMessage() {
		return super.getMessage() + clazz.getName();
	}
	
}






