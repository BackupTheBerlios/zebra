//$Id: ScheduledEntityAction.java,v 1.6.2.3 2003/11/27 16:09:59 oneovthafew Exp $
package net.sf.hibernate.impl;

import java.io.Serializable;

import net.sf.hibernate.engine.SessionImplementor;
import net.sf.hibernate.impl.SessionImpl.Executable;
import net.sf.hibernate.persister.ClassPersister;


abstract class ScheduledEntityAction implements Executable {
	
	private final SessionImplementor session;
	private final Serializable id;
	private final ClassPersister persister;
	private final Object instance;
	
	protected ScheduledEntityAction(SessionImplementor session, Serializable id, Object instance, ClassPersister persister) {
		this.session = session;
		this.id = id;
		this.persister = persister;
		this.instance = instance;
	}
	
	public final Serializable[] getPropertySpaces() {
		return persister.getPropertySpaces();
	}

	protected final SessionImplementor getSession() {
		return session;
	}

	protected final Serializable getId() {
		return id;
	}

	protected final ClassPersister getPersister() {
		return persister;
	}

	protected final Object getInstance() {
		return instance;
	}
	
}






