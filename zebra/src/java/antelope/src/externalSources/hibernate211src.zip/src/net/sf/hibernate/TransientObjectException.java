//$Id: TransientObjectException.java,v 1.4 2003/04/25 03:40:30 oneovthafew Exp $
package net.sf.hibernate;

/**
 * Throw when the user passes a transient instance to a <tt>Session</tt>
 * method that expects a persistent instance.
 * 
 * @author Gavin King
 */

public class TransientObjectException extends HibernateException {
	
	public TransientObjectException(String s) {
		super(s);
	}
	
}






