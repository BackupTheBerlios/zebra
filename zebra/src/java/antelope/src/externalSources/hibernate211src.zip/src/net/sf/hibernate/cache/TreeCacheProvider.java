//$Id: TreeCacheProvider.java,v 1.1.2.1 2003/11/22 02:27:35 oneovthafew Exp $
package net.sf.hibernate.cache;

import java.util.Properties;

/**
 * Support for JBoss TreeCache
 * @author Gavin King
 */
public class TreeCacheProvider implements CacheProvider {

	public Cache buildCache(String regionName, Properties properties)
		throws CacheException {
		return new TreeCache(regionName, properties);
	}

	public long nextTimestamp() {
		return 0;
		//TreeCache does not provide a cluster time;
	}

}
