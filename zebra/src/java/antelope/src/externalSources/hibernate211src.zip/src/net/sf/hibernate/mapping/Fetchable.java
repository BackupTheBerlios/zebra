//$Id: Fetchable.java,v 1.1.2.3 2003/11/06 13:43:22 oneovthafew Exp $
package net.sf.hibernate.mapping;

/**
 * Any mapping with an outer-join attribute
 * @author Gavin King
 */
public interface Fetchable {
	public int getOuterJoinFetchSetting();
	public void setOuterJoinFetchSetting(int joinedFetch);
}
