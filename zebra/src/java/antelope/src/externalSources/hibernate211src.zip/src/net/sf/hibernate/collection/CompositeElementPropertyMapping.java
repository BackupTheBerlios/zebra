//$Id: CompositeElementPropertyMapping.java,v 1.1.2.5 2003/09/08 11:32:25 oneovthafew Exp $
package net.sf.hibernate.collection;

import net.sf.hibernate.MappingException;
import net.sf.hibernate.engine.SessionFactoryImplementor;
import net.sf.hibernate.persister.AbstractPropertyMapping;
import net.sf.hibernate.type.AbstractComponentType;
import net.sf.hibernate.type.Type;

/**
 * @author Gavin King
 */
public class CompositeElementPropertyMapping extends AbstractPropertyMapping {
	
	private final AbstractComponentType compositeType;
	public CompositeElementPropertyMapping(String[] elementColumns, AbstractComponentType compositeType, SessionFactoryImplementor factory) 
	throws MappingException {
		
		this.compositeType = compositeType;
		
		initComponentPropertyPaths(null, compositeType, elementColumns, factory);

	}
	
	public Type getType() {
		return compositeType;
	}

	protected String getClassName() {
		return compositeType.getName();
	}

}
