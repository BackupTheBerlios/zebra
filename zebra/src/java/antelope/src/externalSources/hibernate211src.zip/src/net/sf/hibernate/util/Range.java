//$Id: Range.java,v 1.4 2003/06/15 12:45:08 oneovthafew Exp $
package net.sf.hibernate.util;

public final class Range {
	
	public static int[] range(int begin, int length) {
		int[] result = new int[length];
		for ( int i=0; i<length; i++ ) {
			result[i]=begin + i;
		}
		return result;
	}
	
	private Range() {}
}







