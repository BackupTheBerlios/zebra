//$Id: HibernateProxy.java,v 1.3 2003/01/05 02:11:22 oneovthafew Exp $
package net.sf.hibernate.proxy;

import java.io.Serializable;

public interface HibernateProxy extends Serializable {
	public Object writeReplace();
}







