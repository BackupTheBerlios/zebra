//$Id: IdentifierBag.java,v 1.1.2.3 2003/12/01 05:29:15 oneovthafew Exp $
package net.sf.hibernate.mapping;

import net.sf.hibernate.type.PersistentCollectionType;
import net.sf.hibernate.type.TypeFactory;

/**
 * An <tt>IdentifierBag</tt> has a primary key consisting of 
 * just the identifier column
 */
public class IdentifierBag extends IdentifierCollection {
	
	public IdentifierBag(PersistentClass owner) {
		super(owner);
	}

	public PersistentCollectionType getCollectionType() {
		return TypeFactory.idbag( getRole() );
	}
	
}







