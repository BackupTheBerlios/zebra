//$Id: ObjectDeletedException.java,v 1.4.2.1 2003/11/27 09:30:48 oneovthafew Exp $
package net.sf.hibernate;

import java.io.Serializable;

/**
 * Thrown when the user tries to do something illegal with a deleted 
 * object.
 * 
 * @author Gavin King
 */
public class ObjectDeletedException extends UnresolvableObjectException {
	
	public ObjectDeletedException(String message, Serializable identifier, Class clazz) {
		super(message, identifier, clazz);
	}
	
}







