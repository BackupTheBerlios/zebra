//$Id: NotExpression.java,v 1.3.2.3 2003/11/12 09:02:43 oneovthafew Exp $
package net.sf.hibernate.expression;

import java.util.Map;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.engine.SessionFactoryImplementor;
import net.sf.hibernate.engine.TypedValue;

/**
 * Negates another criterion
 * @author Gavin King
 */
public class NotExpression extends AbstractCriterion {
	
	private Criterion criterion;
	
	NotExpression(Criterion criterion) {
		this.criterion = criterion;
	}

	public String toSqlString(
		SessionFactoryImplementor sessionFactory,
		Class persistentClass,
		String alias, 
		Map aliasClasses)
		throws HibernateException {
		return "not " + criterion.toSqlString(sessionFactory, persistentClass, alias, aliasClasses);
	}

	public TypedValue[] getTypedValues(
		SessionFactoryImplementor sessionFactory,
		Class persistentClass, Map aliasClasses)
		throws HibernateException {
		return criterion.getTypedValues(sessionFactory, persistentClass, aliasClasses);
	}

	public String toString() {
		return "not " + criterion.toString();
	}

}
