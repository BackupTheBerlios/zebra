//$Id: EqualsHelper.java,v 1.1.2.1 2003/10/25 07:43:54 oneovthafew Exp $
package net.sf.hibernate.util;

/**
 * @author Gavin King
 */
public final class EqualsHelper {

	public static boolean equals(Object x, Object y) {
		return x==null ? 
			y==null : 
			x==y || x.equals(y);
	}
	private EqualsHelper() {}

}
