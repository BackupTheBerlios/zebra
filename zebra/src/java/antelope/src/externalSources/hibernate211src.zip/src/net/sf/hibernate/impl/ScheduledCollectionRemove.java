//$Id: ScheduledCollectionRemove.java,v 1.7.2.5 2003/11/05 09:01:29 oneovthafew Exp $
package net.sf.hibernate.impl;

import java.io.Serializable;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.collection.CollectionPersister;
import net.sf.hibernate.engine.SessionImplementor;

final class ScheduledCollectionRemove extends ScheduledCollectionAction implements SessionImpl.Executable {
	
	private boolean emptySnapshot;
	
	public ScheduledCollectionRemove(CollectionPersister persister, Serializable id, boolean emptySnapshot, SessionImplementor session) {
		super(persister, id, session);
		this.emptySnapshot = emptySnapshot;
	}
	
	public void execute() throws HibernateException {
		CollectionPersister persister = getPersister();
		if ( persister.hasCache() ) setLock( persister.getCache().lock( getId() ) );
		if (!emptySnapshot) persister.remove( getId(), getSession() );
		if ( persister.hasCache() ) persister.getCache().evict( getId() );
	}
	
	
}







