//$Id: GtExpression.java,v 1.3 2003/05/24 06:51:17 oneovthafew Exp $
package net.sf.hibernate.expression;

/**
 * @author Gavin King
 */
public class GtExpression extends SimpleExpression {
		
	GtExpression(String propertyName, Object value) {
		super(propertyName, value);
	}

	/**
	 * @see net.sf.hibernate.expression.SimpleExpression#getOp()
	 */
	String getOp() {
		return ">";
	}

}
