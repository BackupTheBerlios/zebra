//$Id: IdentityGenerator.java,v 1.2.2.2 2003/11/09 12:19:07 oneovthafew Exp $
package net.sf.hibernate.id;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.engine.SessionImplementor;

import java.io.Serializable;
import java.sql.SQLException;

/**
 * The IdentityGenerator for autoincrement/identity key generation.
 * <br><br>
 * Indicates to the <tt>Session</tt> that identity (ie. identity/autoincrement
 * column) key generation should be used.
 * 
 * @author Christoph Sturm
 */
public class IdentityGenerator implements IdentifierGenerator {
	
	public Serializable generate(SessionImplementor s, Object obj) throws SQLException, HibernateException {
		return IdentifierGeneratorFactory.IDENTITY_COLUMN_INDICATOR;
	}

}






