package org.apache.turbine.services.pull.tools;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2003 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.util.Map;

import org.apache.commons.configuration.Configuration;

import org.apache.turbine.Turbine;
import org.apache.turbine.pipeline.PipelineData;
import org.apache.turbine.services.pull.ApplicationTool;
import org.apache.turbine.util.RunData;
import org.apache.turbine.util.uri.DataURI;

/**
 * Terribly simple tool to translate URIs into Turbine Links.
 * Equivalent to URIUtils.getAbsoluteLink() in a pull tool.
 * 
 * <p>
 * If you're missing any routines from the 'old' $content tool concerning
 * path_info or query data, you did use the wrong tool then. You should've used
 * the TemplateLink tool which should be available as "$link" in your context.
 * <p>
 *
 * This is an application pull tool for the template system. You should <b>not</b>
 * use it in a normal application!
 *
 * @author <a href="mailto:hps@intermeta.de">Henning P. Schmiedehausen</a>
 * @author <a href="mailto:peter@courcoux.biz">Peter Courcoux</a>
 * @version $Id: ContentTool.java,v 1.5 2004/08/02 08:57:34 epugh Exp $
 */

public class ContentTool
    implements ApplicationTool
{
    /** Prefix for Parameters for this tool */
    public static final String CONTENT_TOOL_PREFIX = "tool.content";

    /** 
     * Should this tool add Container Encoding to the URIs returned?
     * True might cause trouble e.g. if you run with Apache HTTP Daemon / Tomcat Combo.
     *
     * Default is false (like Turbine 2.2)
     */
    public static final String CONTENT_TOOL_ENCODING_KEY = "want.encoding";

    /** Default Value for CONTENT_TOOL_ENCODING_KEY */
    public static final boolean CONTENT_TOOL_ENCODING_DEFAULT = false;
    
    /** Should this tool return relative URIs or absolute? Default: Absolute. */
    public static final String CONTENT_TOOL_RELATIVE_KEY = "want.relative";

    /** Default Value for CONTENT_TOOL_RELATIVE_KEY */
    public static final boolean CONTENT_TOOL_RELATIVE_DEFAULT = false;

    /** Do we want the container to encode the response? */
    boolean wantEncoding = false;
    
    /** Do we want a relative link? */
    boolean wantRelative = false;
    
    /** Caches a DataURI object which provides the translation routines */
    private DataURI dataURI = null;
    
    /**
     * C'tor
     */
    public ContentTool()
    {
    }

    /*
     * ========================================================================
     *
     * Application Tool Interface
     *
     * ========================================================================
     *
     */

    /**
     * This will initialise a ContentTool object that was
     * constructed with the default constructor (ApplicationTool
     * method).
     *
     * @param data assumed to be a RunData object
     */
    public void init(Object data)
    {
        // we just blithely cast to RunData as if another object
        // or null is passed in we'll throw an appropriate runtime
        // exception.
        if (data instanceof PipelineData)
        {
            PipelineData pipelineData = (PipelineData) data;
            Map runDataMap = (Map) pipelineData.get(RunData.class);
            RunData runData = (RunData)runDataMap.get(RunData.class);
            dataURI = new DataURI(runData);
        }
        else
        {
            dataURI = new DataURI((RunData) data);

        }

        Configuration conf = 
                Turbine.getConfiguration().subset(CONTENT_TOOL_PREFIX);

        if (conf != null)
        {
            wantRelative = conf.getBoolean(CONTENT_TOOL_RELATIVE_KEY,
                    CONTENT_TOOL_RELATIVE_DEFAULT);

            wantEncoding = conf.getBoolean(CONTENT_TOOL_ENCODING_KEY,
                    CONTENT_TOOL_ENCODING_DEFAULT);
        }
        
        if (!wantEncoding)
        {
            dataURI.clearResponse();
        }
    }

    /**
     * Refresh method - does nothing
     */
    public void refresh()
    {
        // empty
    }

    /**
     * Returns the Turbine URI of a given Path
     *
     * @param path The path to translate
     *
     * @return Turbine translated absolute path
     */
    public String getURI(String path)
    {
        dataURI.setScriptName(path);

        return wantRelative ? 
                dataURI.getRelativeLink() : dataURI.getAbsoluteLink();
    }

    /**
     * Returns the Turbine URI of a given Path. The
     * result is always an absolute path starting with
     * the server scheme (http/https).
     *
     * @param path The path to translate
     *
     * @return Turbine translated absolute path
     */
    public String getAbsoluteURI(String path)
    {
        dataURI.setScriptName(path);

        return dataURI.getAbsoluteLink();
    }

    /**
     * Returns the Turbine URI of a given Path. The
     * result is always relative to the context of
     * the application.
     *
     * @param path The path to translate
     *
     * @return Turbine translated absolute path
     */
    public String getRelativeURI(String path)
    {
        dataURI.setScriptName(path);

        return dataURI.getRelativeLink();
    }

}
